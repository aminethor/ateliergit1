#include <gtk/gtk.h>





void
on_button8rec_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7rec_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6rec_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9rec_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5rec_clicked                     (GtkButton       *button,
                                        gpointer         user_data);













void
on_button24rec_clicked                    (GtkButton       *button,
                                        gpointer         user_data);





void
on_radiobutton1rec_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2rec_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button10rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button11rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13rec_clicked                 (GtkWidget      *obj,
                                        gpointer         user_data);

void
on_button20rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button22rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button14rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button15rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button16rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button18rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button17rec_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button19rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button21rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button25rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button23rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1rec_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button1rec_clicked                  (GtkButton       *button,
                                        gpointer         user_data);
