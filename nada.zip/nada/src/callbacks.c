#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "reclamation.h"

int x,y,n,nada;










void
on_button10rec_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button11rec_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *windowafficherrec;




	GtkWidget *treeview11rec;
	
	GtkWidget *ajoutreclamation;
	ajoutreclamation=lookup_widget(button,"ajoutreclamation");
      gtk_widget_destroy(ajoutreclamation);
	
	
         windowafficherrec=create_affichreclamation();
         gtk_widget_show(windowafficherrec); 
	
	treeview11rec=lookup_widget(windowafficherrec,"treeview1rec");

	afficherrec(treeview11rec);
}


void
on_button13rec_clicked                    (GtkWidget       *obj, gpointer         user_data)
{
GtkWidget *entry3rec; 
GtkWidget *entry9rec; 
GtkWidget *combobox1rec;
GtkWidget  *spin3nd;
GtkWidget  *spin4nd;
GtkWidget  *spin5nd;
//GtkWidget *pRadio1;
//GtkWidget *pRadio3;

reclamation t;

GtkWidget *ctrl;
GtkWidget *info4;
GtkWidget *ajoutreclamation;
GtkWidget *affichreclamation;
GtkWidget *treeview11rec;


entry3rec=lookup_widget(obj,"entry3rec");
combobox1rec=lookup_widget(obj,"combobox1rec");
spin3nd=lookup_widget(obj,"spinbutton3rec");
spin4nd=lookup_widget(obj,"spinbutton4rec");
spin5nd=lookup_widget(obj,"spinbutton5rec");
entry9rec=lookup_widget(obj,"entry9rec");
strcpy(t.id,gtk_entry_get_text(GTK_ENTRY(entry3rec)));
strcpy(t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1rec)));
strcpy(t.reclamation,gtk_entry_get_text(GTK_ENTRY(entry9rec)));
t.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin3nd));
t.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin4nd));
t.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin5nd));
strcpy(t.reclamation,gtk_entry_get_text(GTK_ENTRY(entry9rec)));


 
  if (idexistee(t.id)==1)
    {ctrl= lookup_widget(obj,"label54rec");
gtk_label_set_text(GTK_LABEL(ctrl),"ce id existe deja😔");}

else {
ajouterrec(t);
info4=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"reclamation ajouté avec succées!");
switch (gtk_dialog_run(GTK_DIALOG(info4)))
{
case GTK_RESPONSE_OK:
gtk_widget_destroy(info4);
break;

}
}

ajoutreclamation=lookup_widget(obj,"ajoutreclamation");
      gtk_widget_destroy(ajoutreclamation);
      affichreclamation=lookup_widget(obj,"affichreclamation");
      affichreclamation=create_affichreclamation();
      gtk_widget_show(affichreclamation);
      treeview11rec=lookup_widget(affichreclamation,"treeview1rec");
afficherrec(treeview11rec);

}




void
on_button14rec_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *choisir;
GtkWidget *affichreclamation;

affichreclamation=lookup_widget(button,"affichreclamation");
      gtk_widget_destroy(affichreclamation);




choisir=create_choisir();
gtk_widget_show (choisir);
}


void
on_button8rec_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *supprec;
GtkWidget *choisir;

choisir=lookup_widget(button,"choisir");
      gtk_widget_destroy(choisir);



supprec=create_supprec();
gtk_widget_show (supprec);
}


void
on_button7rec_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modifrecher;
GtkWidget *choisir;


choisir=lookup_widget(button,"choisir");
      gtk_widget_destroy(choisir);

modifrecher=create_modifrecher();
gtk_widget_show (modifrecher);








}


void
on_button6rec_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *choisir;
GtkWidget *windowafficherrec;
	GtkWidget *treeview11rec;
	
	choisir=lookup_widget(button,"choisir");
      gtk_widget_destroy(choisir);
         windowafficherrec=create_affichreclamation();
         gtk_widget_show(windowafficherrec); 
	
	treeview11rec=lookup_widget(windowafficherrec,"treeview1rec");

	afficherrec(treeview11rec);
	
	
}


void
on_button9rec_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *sure;
GtkWidget *choisir;


choisir=lookup_widget(button,"choisir");
      gtk_widget_destroy(choisir);




sure=create_modifrecher();
gtk_widget_show (sure);
}


void
on_button5rec_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajoutreclamation;
GtkWidget *choisir;


choisir=lookup_widget(button,"choisir");
      gtk_widget_destroy(choisir);

ajoutreclamation=create_ajoutreclamation();
gtk_widget_show (ajoutreclamation);







}


void
on_button15rec_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
char id[50];
GtkWidget *hm;
  
    

	GtkWidget *entry4;
	entry4=lookup_widget(button,"entry4");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(entry4)));
if (idexistee(id)==1){
	supprimerrec(id);}
	else {hm= lookup_widget(button,"label56rec");
gtk_label_set_text(GTK_LABEL(hm),"ce id n'existe pas😫");}
	
}


void
on_button16rec_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{


GtkWidget *supprec;

GtkWidget *choisir;
supprec=lookup_widget(button,"supprec");
      gtk_widget_destroy(supprec);




choisir=create_choisir();
gtk_widget_show (choisir);
}


void
on_button19rec_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *choisir;
GtkWidget *modifrecher;
modifrecher=lookup_widget(button,"modifrecher");
      gtk_widget_destroy(modifrecher);



choisir=create_choisir();
gtk_widget_show (choisir);

}


void
on_button17rec_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{  GtkWidget *info255;
GtkWidget *type2;
char idd[50];
	char typee[50];
	char date1[50];
	char reclamationn[50];
	GtkWidget *entry5rec;
	
	GtkWidget *entry8rec; 
	GtkWidget *entry7rec;
	
	entry5rec=lookup_widget(button,"entry5rec");
	strcpy(idd,gtk_entry_get_text(GTK_ENTRY(entry5rec)));
	type2 = lookup_widget (button, "comboboxrec");
	strcpy(typee,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type2)));
	
	entry8rec=lookup_widget(button,"entry8rec");
	strcpy(date1,gtk_entry_get_text(GTK_ENTRY(entry8rec)));
	entry7rec=lookup_widget(button,"entry7rec");
	strcpy(reclamationn,gtk_entry_get_text(GTK_ENTRY(entry7rec)));
	 modifierrec(idd,typee,reclamationn,date1);
	 
	 info255=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"modification effectuée avec succées!");
switch (gtk_dialog_run(GTK_DIALOG(info255)))
{
case GTK_RESPONSE_OK:
gtk_widget_destroy(info255);
break;

}
	 
	 
	 
	 
	 
}


void
on_button18rec_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{






GtkWidget *info256;


GtkWidget *entry5rec;
GtkWidget *type;
GtkWidget *entry7rec;
GtkWidget *entry8rec;
GtkWidget *labelnad;
GtkWidget *labelnada;
FILE *fa;
int i=0;
char p[200][200]={"FOYER","RESTAURANT"};
char id1[50];
reclamation t;
char date[50];
fa=fopen("bloc.txt","r");
entry5rec=lookup_widget(button,"entry5rec");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(entry5rec)));
if (fa!=NULL)
 {
    	while(fscanf(fa,"%s %s %s %s \n",t.id,t.type,t.reclamation,date)!=EOF)
 {
			if(strcmp(id1,t.id)==0){
			
			
			
			
			while ((i<2) && (strcmp(p[i],t.type))!=0)
 
 
{i=i+1;}

				entry5rec=lookup_widget(button,"entry5rec");
				type = lookup_widget (button, "comboboxrec");
gtk_combo_box_set_active(GTK_COMBO_BOX(type),i);
				entry7rec=lookup_widget(button,"entry7rec");
				entry8rec=lookup_widget(button,"entry8rec");
				gtk_entry_set_text(GTK_ENTRY(entry5rec),t.id);
				
				gtk_entry_set_text(GTK_ENTRY(entry7rec),t.reclamation);
				gtk_entry_set_text(GTK_ENTRY(entry8rec),date);
				labelnad=lookup_widget(button,"label55rec");
                           gtk_label_set_text(GTK_LABEL(labelnad),"ce id existe 😁 ");
                           info256=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"reclamation trouvé avec succés!");
switch (gtk_dialog_run(GTK_DIALOG(info256)))
{
case GTK_RESPONSE_OK:


gtk_widget_destroy(info256);
break;
} 
				}
				
				
				
			
			 else 
			
			
			
{
     





}







}

}

}




void
on_treeview1rec_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
                                        
                                        
  {   reclamation rec;
  GtkTreeIter iter;
      gchar* id;
      gchar* reclamation;
      gchar* type;
      gint *jour;
      gint* mois;
      
      gint* annee;
      
      
      GtkTreeModel *model=gtk_tree_view_get_model(treeview);
      if (gtk_tree_model_get_iter(model,&iter,path))
      { gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,1,&reclamation,2,&type,3,&jour,4,&mois,5,&annee,-1);
      strcpy(rec.id,id);
      strcpy(rec.reclamation,reclamation);
      strcpy(rec.type,type);
      rec.date.jour=jour;
      rec.date.mois=mois;
      rec.date.annee=annee; 
      supprimerrec(id);
      afficherrec(treeview);}
      
      
      }
                                           
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        









void
on_radiobutton1rec_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{GtkWidget *modifrecher;
GtkWidget *sure;
  
 if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
 {  


sure=lookup_widget(togglebutton,"sure");
      gtk_widget_destroy(sure);

modifrecher=create_modifrecher();
gtk_widget_show (modifrecher);
}
}


void
on_button20rec_clicked                    (GtkButton       *button,
                                        gpointer         user_data)

{
GtkWidget *sure;
GtkWidget *affichreclamation;

affichreclamation=lookup_widget(button,"affichreclamation");
      gtk_widget_destroy(affichreclamation);


sure=create_sure();
gtk_widget_show (sure);
}




void
on_button21rec_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{


GtkWidget *sure;



GtkWidget *windowafficher;
	GtkWidget *treeview11;
	sure=lookup_widget(button,"sure");
      gtk_widget_destroy(sure);
	
	
	
         windowafficher=create_affichreclamation();
         gtk_widget_show(windowafficher); 
	
	treeview11=lookup_widget(windowafficher,"treeview1");

	afficherrec(treeview11);
}


void
on_radiobutton2rec_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_button22rec_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajoutreclamation;
GtkWidget *affichreclamation;


affichreclamation=lookup_widget(button,"affichreclamation");
      gtk_widget_destroy(affichreclamation);


ajoutreclamation=create_ajoutreclamation();
gtk_widget_show (ajoutreclamation);
}


void
on_button23rec_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *choisir;
GtkWidget *serviceplusreclame;


serviceplusreclame=lookup_widget(button,"serviceplusreclame");
      gtk_widget_destroy(serviceplusreclame);


choisir=create_choisir();
gtk_widget_show (choisir);
}


void
on_button24rec_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{


GtkWidget *choisir;





GtkWidget *serviceplusreclame;


choisir=lookup_widget(button,"choisir");
      gtk_widget_destroy(choisir);

serviceplusreclame=create_serviceplusreclame();
gtk_widget_show (serviceplusreclame);}





    



























void
on_button25rec_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{char ch3[100];
char ch4[]="foyer";
char ch5[]="restau";
char ch6[]="RESTAU ET FOYER";
GtkWidget* output;

n=service_plus_reclame();

if (n==0)

   {sprintf(ch3,"%s",ch4);
output=lookup_widget(button,"label53rec");
gtk_label_set_text(GTK_LABEL(output),"foyer🏡");
}
else if (n==1)
  { 
  sprintf(ch3,"%s",ch5);
output= lookup_widget(button,"label53rec");
gtk_label_set_text(GTK_LABEL(output),"restauuu🍔");
}

else if (n==2)
{ 
  sprintf(ch3,"%s",ch6);
output= lookup_widget(button,"label53rec");
gtk_label_set_text(GTK_LABEL(output),"RESTAU ET FOYER");
}





}














void
on_button1rec_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{                }






