#include <gtk/gtk.h>
int x,y;


/************************Fadi***************************/
void
on_button_login_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
/////////////////////////////////////////////////////////Nada////////////////////////////////////////////////////////////////////////////


void
on_button8rec_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7rec_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6rec_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9rec_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5rec_clicked                     (GtkButton       *button,
                                        gpointer         user_data);













void
on_button24rec_clicked                    (GtkButton       *button,
                                        gpointer         user_data);





void
on_radiobutton1rec_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2rec_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button10rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button11rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13rec_clicked                 (GtkWidget      *obj,
                                        gpointer         user_data);

void
on_button20rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button22rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button14rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button15rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button16rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button18rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button17rec_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button19rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button21rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button25rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button23rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1rec_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button1rec_clicked                  (GtkButton       *button,
                                        gpointer         user_data);





/////////////////////////////////////Ichrak/////////////////////////////////////////////////////////

void
on_button_ajout1_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_menu1_clicked                (GtkWidget      *button,
                                        gpointer         user_data);


void
on_buttonajout2menu_clicked                (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button5_menu_ajout_clicked          (GtkWidget       *button,
                                        gpointer         user_data);



void
on_buttonrecherchermenu1_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonmodifiermenu1_clicked              (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button10retourner_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button11rechercher_clicked          (GtkWidget      *button,
                                        gpointer         user_data);

void
on_radiobuttonpetit_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttondinner_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttondejeuner_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview1menu_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button7actualiser_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button4retourmenu_clicked            (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button4supprimer_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonmeilleur_clicked              (GtkWidget      *button,
                                        gpointer         user_data);

void
on_buttonmeilleurmenu_clicked          (GtkWidget        *button,
                                        gpointer         user_data);

void
on_radiobutton3modif_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1modif_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonvalidermodif_clicked          (GtkWidget        *button,
                                        gpointer         user_data);

void
on_radiobutton2modif_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_buttonquittermenu_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1salade_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2soupe_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3barquette_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonquittermenu_clicked           (GtkButton       *button,
                                        gpointer         user_data);



void
on_buttonajout2menu_clicked            (GtkWidget      *button,
                                        gpointer         user_data);


void
on_button4retourmenu1_clicked           (GtkWidget      *button,
                                        gpointer         user_data);



void
on_checkbuttonancien_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


////////////////////////////hela///////////////////////////////////////


void
on_button_A_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_H_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_E_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_C_clicked                    (GtkButton       *button,
                                        gpointer         user_data);


void
on_radiobutton_H_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_T_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_G_clicked                    (GtkButton       *button,
                                        gpointer         user_data);



void
on_button_I_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_J_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_K_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_L_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_M_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_N_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_D_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_F_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_O_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_P_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_Q_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_R_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_S_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);





/////////////////////////////Chahine///////////////////////////////



void
on_non_def_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_def_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ajout_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_gotodef_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rech_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_actu_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modif_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supp_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_modif_non_def_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_modif_def_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_enreg_modif_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modif_rech_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_backEdit_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_backReche_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_backCapDef_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rech_rech_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_quitter_cap_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_actu_def_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeListCap_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_supp_modif_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);



/////////////////////////////Amine///////////////////////////////





void
on_button1_valider_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_dec_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton1_aff_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_aj_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button5_ok_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button6_recher_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button4_re_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button7_ajou_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button8_modif_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_button10_Delete_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_user_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);


void
on_button1_aff_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton1_xo_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_aq_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_kn_clicked                  (GtkButton       *button,
                                        gpointer         user_data);
void
on_button1_ax_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button1_Bn_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button2_Vc_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button1_Sz_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_AFf_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_h_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_f_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_GH_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data);



void
on_button2_etud_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_af_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_ar_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_nut_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_tec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_Seeee_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_search_close                        (GtkDialog       *dialog,
                                        gpointer         user_data);

void
on_button1_Ver_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_Mv_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_tit_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_Okv_clicked                 (GtkButton       *button,
                                        gpointer         user_data);



void
on_button11_AmDa_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_trouve_meilleur_menu_clicked (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonfedi_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonnada_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonhela_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button17_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button19_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button20_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button21_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button22_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button23_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);
