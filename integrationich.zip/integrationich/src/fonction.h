#include <gtk/gtk.h>
typedef struct {
              char nom[100];
              char prenom[100];
              char login[100];
              char password[100];
              int role;
              int jour;
              int mois;
              int annee;   
              char id[100];
              char date[100];
              char sexe[100];}utilisateur;
void ajouter_i(char nom_fichier[100],utilisateur u);
void modifier_no(char nom_fichier[100],utilisateur u);
void supprimer(char nom_fichier[100],char Id[100]);
int chercher(char nom_fichier[100],char Id[100]);
//void afficher(char nom_fichier[100]);
void afficher_u(GtkWidget *liste);
void stat();
void suppr(utilisateur u);
void rechercher_k(GtkWidget *liste,char Id[100]);
void rechercher_homme(GtkWidget *liste);
void rechercher_femme(GtkWidget *liste);

