#ifndef FONCTION_H_INCLUDED
#define FONCTION_H_INCLUDED
#include<gtk/gtk.h>

typedef struct
{
	char entree[60];
	char plat_principale[50];
	char dessert[50];
}plat;
typedef struct
{
	char jour[20];
	char  temps[20];
	plat menu;
	
}menu;
typedef struct
{
  int jd;//jour
  int td;//ptit dej ou de..
  float kgd;////dechets en kg
}dechet;

void afficher(GtkWidget *liste);
void afficher1(GtkWidget *liste);
void ajout_menu(menu m);
void supprimer_menu(menu m);
void rechercher_menu2(char temps[]);
void modifier_menu(menu m);
void meilleur_menu(char meill11[],char meill13[],char meill21[],char meill23[],char meill31[],char meill33[]);
int controle(char chjour[],char chtemps[]);
menu chercher_menu(char chjour[],char chtemps[]);
void meilleur_menu1(char text1[],char text2[],char text3[],char text4[]);
#endif
