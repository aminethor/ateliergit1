#ifndef __FONCTION__H__
#define __FONCTION__H__

typedef struct 
{
int j;
int m;
int a;
}date1;

typedef struct capteur
{
char id[20];
char type[20];
char marque[20];
char etat[30];
date1 d;
int prix;
int valeur;
}capteur;


void ajouter_capteur(capteur c);
void supprimer_capteur(char id[]);
void modifier_capteur(capteur y);
void afficher_capteur(GtkWidget *liste);


capteur chercher_capteur(char id[]);
int idExiste(char id[]);


#endif
