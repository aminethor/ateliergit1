#include "talbi.h"
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
enum
{
EID,
EQUANTITE,
ENOM,
EEMBALLAGE,
EPRIX,
EJOURS,
EMOIS,
EANNEE,
EORIGINE,
COLUMNS

};

void afficher_stock(GtkWidget *liste)
{
GtkCellRenderer  *renderer;
GtkTreeViewColumn  *column;
GtkTreeIter  iter;
GtkListStore  *store;
char id5[9];
char quantite5[9];
char nom5[30];
char emballage5[30];
char prix5[30];
int jours5,mois5,annee5;
char origine5[30];
FILE *f5=NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("quantite",renderer,"text",EQUANTITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);    
renderer=gtk_cell_renderer_text_new();

column=gtk_tree_view_column_new_with_attributes("emballage",renderer,"text",EEMBALLAGE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();

column=gtk_tree_view_column_new_with_attributes("prix",renderer,"text",EPRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new(); 



column=gtk_tree_view_column_new_with_attributes("jours",renderer,"text",EJOURS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",EMOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",EANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("origine",renderer,"text",EORIGINE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);       

}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);
f5=fopen("hela.txt","r");

if (f5==NULL)
{
return;
}
else 
{
f5= fopen("hela.txt","a+");
while 
(fscanf(f5,"%s %s %s %s %s  %d %d %d %s \n",id5,quantite5,nom5,emballage5,prix5,&jours5,&mois5,&annee5,origine5)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,EID,id5,EQUANTITE,quantite5,ENOM,nom5,EEMBALLAGE,emballage5,EPRIX,prix5,EJOURS,annee5,EMOIS,mois5,EANNEE,jours5,EORIGINE,origine5,-1);
}
fclose(f5);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);

}
}
void supprimer_stock(stock t) 
{

stock t2;
FILE *f,*g;
f=fopen("hela.txt","r");
g=fopen("tmp9.txt","w");
if ((f==NULL) || (g==NULL))
{
return;
}
else
{
while (fscanf(f," %s %s %s %s %s %d %d %d %s \n",t2.id,t2.quantite,t2.nom,t2.emballage,t2.prix,&t2.dn.jours,&t2.dn.mois,&t2.dn.annee,t2.origine)!=EOF)
{
if (strcmp(t.id,t2.id)!=0)
fprintf(g,"%s %s %s %s %s %d %d %d %s \n",t2.id,t2.quantite,t2.nom,t2.emballage,t2.prix,&t2.dn.jours,&t2.dn.mois,&t2.dn.annee,t2.origine);
}
fclose(f);
fclose(g);
remove("hela.txt");
rename("tmp9.txt","hela.txt");
}


}
void modifier( stock t)
{ 
char id1[9];
char quantite1[9];
char nom1[30];
char emballage1[30];
char prix1[30];
int jours1,mois1,annee1;
char origine1[30];
FILE *f=NULL;
FILE *g=NULL;
f=fopen("hela.txt","r");
g=fopen("tmp33.txt","a+");


while (fscanf(f,"%s %s %s %s %s  %d %d %d %s \n",id1,quantite1,nom1,emballage1,prix1,&jours1,&mois1,&annee1,origine1)!=EOF)
{
if (strcmp(id1,t.id)!=0)
{



fprintf(g,"%s %s %s %s %s  %d %d %d %s \n",id1,quantite1,nom1,emballage1,prix1,jours1,mois1,annee1,origine1);

}
else 
{
fprintf(g,"%s %s %s %s %s %d %d %d %s \n",t.id,t.quantite,t.nom,t.emballage,t.prix,t.dn.jours,t.dn.mois,t.dn.annee,t.origine);
}





}

fclose(f);
fclose(g);
remove("hela.txt");
rename("tmp33.txt","hela.txt");


}




void afficher_stockk(GtkWidget *liste)
{
GtkCellRenderer  *renderer;
GtkTreeViewColumn  *column;
GtkTreeIter  iter;
GtkListStore  *store;
char id5[9];
char quantite5[9];
char nom5[30];
char emballage5[30];
char prix5[30];
int jours5,mois5,annee5;
char origine5[30];
FILE *f5=NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("quantite",renderer,"text",EQUANTITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);    
renderer=gtk_cell_renderer_text_new();

column=gtk_tree_view_column_new_with_attributes("emballage",renderer,"text",EEMBALLAGE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();

column=gtk_tree_view_column_new_with_attributes("prix",renderer,"text",EPRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new(); 



column=gtk_tree_view_column_new_with_attributes("jours",renderer,"text",EJOURS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",EMOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",EANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("origine",renderer,"text",EORIGINE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);       

}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);
f5=fopen("tmp77.txt","r");

if (f5==NULL)
{
return;
}
else 
{
f5= fopen("tmp77.txt","a+");
while 
(fscanf(f5,"%s %s %s %s %s  %d %d %d %s \n",id5,quantite5,nom5,emballage5,prix5,&jours5,&mois5,&annee5,origine5)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,EID,id5,EQUANTITE,quantite5,ENOM,nom5,EEMBALLAGE,emballage5,EPRIX,prix5,EJOURS,annee5,EMOIS,mois5,EANNEE,jours5,EORIGINE,origine5,-1);
}
fclose(f5);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);

}
}

/*void vider(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("quantite",renderer,"text",EQUANTITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);    
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("emballage",renderer,"text",EEMBALLAGE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prix",renderer,"text",EPRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new(); 



column=gtk_tree_view_column_new_with_attributes("jours",renderer,"text",EJOURS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",EMOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",EANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("origine",renderer,"text",EORIGINE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);       


      
}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);
gtk_list_store_append(store,&iter);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));

}*/
int verif_id(char id[])
{
int trouve=-1;
FILE *f=NULL;
stock t2;
f=fopen("hela.txt","r");
if(f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %d %d %d %s \n",t2.id,t2.quantite,t2.nom,t2.emballage,t2.prix,&t2.dn.jours,&t2.dn.mois,&t2.dn.annee,t2.origine)!=EOF)
{
if ((strcmp(id,t2.id)==0))
trouve=1;
}
fclose(f);
}
return (trouve);
}






int idexisteee(char idhela[])
{ stock t;
  FILE *f;
  int res;
  f=fopen("hela.txt","r");
  
  if (f!=NULL)
  { while (fscanf(f,"%s %s %s %s %s %d %d %d %s \n",t.id,t.quantite,t.nom,t.emballage,t.prix,&t.dn.jours,&t.dn.mois,&t.dn.annee,t.origine)!=EOF)
  {
  if (strcmp(t.id,idhela)==0)
  {return 1;}

}}
fclose(f);
return 0;
}
int repture_stock(char id9[])
{
FILE *f=NULL;
f=fopen("hela.txt", "r");
int nb;
stock t;
if (f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %d %d %d %s \n",t.id,t.quantite,t.nom,t.emballage,t.prix,&t.dn.jours,&t.dn.mois,&t.dn.annee,t.origine)!=EOF)
{if (strcmp(id9,t.id)==0)
{
   if (strcmp(t.quantite,"0"))
     nb=1;
   else 
     nb=0;
}
}
}
fclose(f);
return nb;
}



















