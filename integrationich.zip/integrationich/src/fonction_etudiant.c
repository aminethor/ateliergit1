#include "fonction_etudiant.h"
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
enum
{
EID,
ECIN,
ENOM,
EPRENOM,
ESEXE,
EEMAIL,
ETEL,
EETAGE,
ECHAMBRE,
EJOURS,
EMOIS,
EANNEE,
ECLASSE,
COLUMNS

};
int verif_etudiant(char log[],char Pw[])
{
int trouve=-1;
FILE *f=NULL;
char ch1[20];
char ch2[20];
f=fopen("agent_foyer.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s %s ",ch1,ch2)!=EOF)
{
if ((strcmp(ch1,log)==0)&&(strcmp(ch2,Pw)==0))
trouve=1;
}
fclose(f);
}
return (trouve);
}
void afficher_etudiant(GtkWidget *liste)
{
GtkCellRenderer  *renderer;
GtkTreeViewColumn  *column;
GtkTreeIter  iter;
GtkListStore  *store;
char id[30];
char cin[30];
char nom[30];
char prenom[100];
char sexe[100];
char classe[100];
char email[30];
char tel[30];
int etage;
int chambre;
int jours,mois,annee;
FILE *f=NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",ECIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);    
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("email",renderer,"text",EEMAIL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new(); 
column=gtk_tree_view_column_new_with_attributes("tel",renderer,"text",ETEL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new(); 



column=gtk_tree_view_column_new_with_attributes("jours",renderer,"text",EJOURS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",EMOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",EANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("classe",renderer,"text",ECLASSE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);       

column=gtk_tree_view_column_new_with_attributes("etage",renderer,"text",EETAGE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new(); 

column=gtk_tree_view_column_new_with_attributes("chambre",renderer,"text",ECHAMBRE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new();       
}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);
f=fopen("utilisateur.txt","r");

if (f==NULL)
{
return;
}
else 
{
f= fopen("utilisateur.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",id,cin,nom,prenom,sexe,email,tel,&etage,&chambre,&jours,&mois,&annee,classe)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,EID,id,ECIN,cin,ENOM,nom,EPRENOM,prenom,ESEXE,sexe,EEMAIL,email,ETEL,tel,EETAGE,etage,ECHAMBRE,chambre,EJOURS,annee,EMOIS,mois,EANNEE,jours,ECLASSE,classe,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);

}
}
void supprimer_etudiant(etudiant e) 
{

etudiant e2;
FILE *f,*g;
f=fopen("utilisateur.txt","r");
g=fopen("tmp.txt","w");
if ((f==NULL) || (g==NULL))
{
return;
}
else
{
while (fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %s \n",e2.id,e2.cin,e2.nom,e2.prenom,e2.sexe,e2.email,e2.tel,&e2.etage,&e2.chambre,&e2.dn.jours,&e2.dn.mois,&e2.dn.annee,e2.classe)!=EOF)
{
if (strcmp(e.id,e2.id)!=0)
fprintf(g,"%s %s %s %s %s %s %s %d %d %d %d %d %s \n",e2.id,e2.cin,e2.nom,e2.prenom,e2.sexe,e2.email,e2.tel,e2.etage,e2.chambre,e2.dn.jours,e2.dn.mois,e2.dn.annee,e2.classe);
}
fclose(f);
fclose(g);
remove("utilisateur.txt");
rename("tmp.txt","utilisateur.txt");
}


}
void modifier_etudiant(etudiant e)
{ 
char id1[9];
char cin1[9];
char nom1[30];
char prenom1[30];
char sexe1[30];
char email1[30];
char tel1[30];
int etage1;
int chambre1;
int jours1,mois1,annee1;
char classe1[30];
FILE *f=NULL;
FILE *g=NULL;
f=fopen("utilisateur.txt","r");
g=fopen("tmp3.txt","a+");


while (fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %s \n",id1,cin1,nom1,prenom1,sexe1,email1,tel1,&etage1,&chambre1,&jours1,&mois1,&annee1,classe1)!=EOF)
{
if (strcmp(id1,e.id)!=0)
{



fprintf(g,"%s %s %s %s %s %s %s %d %d %d %d %d %s \n",id1,cin1,nom1,prenom1,sexe1,email1,tel1,etage1,chambre1,jours1,mois1,annee1,classe1);

}
else 
{
fprintf(g,"%s %s %s %s %s %s %s %d %d %d %d %d %s \n",e.id,e.cin,e.nom,e.prenom,e.sexe,e.email,e.tel,e.etage,e.chambre,e.dn.jours,e.dn.mois,e.dn.annee,e.classe);
}





}

fclose(f);
fclose(g);
remove("utilisateur.txt");
rename("tmp3.txt","utilisateur.txt");


}




void afficher_etudiantt(GtkWidget *liste)
{
GtkCellRenderer  *renderer;
GtkTreeViewColumn  *column;
GtkTreeIter  iter;
GtkListStore  *store;
char id5[30];
char cin5[30];
char nom5[30];
char prenom5[100];
char sexe5[100];
char classe5[100];
char email5[30];
char tel5[30];
int etage5;
int chambre5;
int jours5,mois5,annee5;
FILE *f5=NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",ECIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);    
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("email",renderer,"text",EEMAIL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new(); 
column=gtk_tree_view_column_new_with_attributes("tel",renderer,"text",ETEL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new(); 



column=gtk_tree_view_column_new_with_attributes("jours",renderer,"text",EJOURS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",EMOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",EANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("classe",renderer,"text",ECLASSE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);       

column=gtk_tree_view_column_new_with_attributes("etage",renderer,"text",EETAGE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new(); 

column=gtk_tree_view_column_new_with_attributes("chambre",renderer,"text",ECHAMBRE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new();       
}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);
f5=fopen("tmp7.txt","r");

if (f5==NULL)
{
return;
}
else 
{
f5= fopen("tmp7.txt","a+");
while 
(fscanf(f5,"%s %s %s %s %s %s %s %d %d %d %d %d %s \n",id5,cin5,nom5,prenom5,sexe5,email5,tel5,&etage5,&chambre5,&jours5,&mois5,&annee5,classe5)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,EID,id5,ECIN,cin5,ENOM,nom5,EPRENOM,prenom5,ESEXE,sexe5,EEMAIL,email5,ETEL,tel5,EETAGE,etage5,ECHAMBRE,chambre5,EJOURS,annee5,EMOIS,mois5,EANNEE,jours5,ECLASSE,classe5,-1);
}
fclose(f5);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);

}
}

void vider_etudiant(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",ECIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);    
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("email",renderer,"text",EEMAIL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new(); 
column=gtk_tree_view_column_new_with_attributes("tel",renderer,"text",ETEL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new(); 



column=gtk_tree_view_column_new_with_attributes("jours",renderer,"text",EJOURS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",EMOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",EANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("classe",renderer,"text",ECLASSE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);       

column=gtk_tree_view_column_new_with_attributes("etage",renderer,"text",EETAGE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new(); 

column=gtk_tree_view_column_new_with_attributes("chambre",renderer,"text",ECHAMBRE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new();       
}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);
gtk_list_store_append(store,&iter);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));

}
int verif_id_etudiant(char id[])
{
int trouve=-1;
FILE *f=NULL;
etudiant e2;
f=fopen("utilisateur.txt","r");
if(f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %s \n",e2.id,e2.cin,e2.nom,e2.prenom,e2.sexe,e2.email,e2.tel,&e2.etage,&e2.chambre,&e2.dn.jours,&e2.dn.mois,&e2.dn.annee,e2.classe)!=EOF)
{
if ((strcmp(id,e2.id)==0))
trouve=1;
}
fclose(f);
}
return (trouve);
}

int verif_email_etudiant (char email[])
{
int trouve =-1;
int i,n;
n=strlen(email);
for (i=0;i<n;i++)
{
if (email[i]=='@')
		trouve=1;
}
return trouve;
}


int verif_tel_etudiant(char tel[])
{
int test=-1;
int i,n;
n=strlen(tel);
printf("\nn est %d ",n);
if (strlen(tel)!=8)
test++;
for (i=1;i<n;i++)
{
if ((tel[i]!='0')&&(tel[i]!='1')&&(tel[i]!='2')&&(tel[i]!='3')&&(tel[i]!='4')&&(tel[i]!='5')&&(tel[i]!='6')&&(tel[i]!='7')&&(tel[i]!='8')&&(tel[i]!='9'))
test++;
}
if ((tel[0]!='9')&&(tel[0]!='2')&&(tel[0]!='5')&&(tel[0]!='7'))
test++;

return test;
}
int verif_cin_etudiant(char tel[])
{
int test=-1;
int i,n;
n=strlen(tel);
printf("\nn est %d ",n);
if (strlen(tel)!=8)
test++;
for (i=1;i<n;i++)
{
if ((tel[i]!='0')&&(tel[i]!='1')&&(tel[i]!='2')&&(tel[i]!='3')&&(tel[i]!='4')&&(tel[i]!='5')&&(tel[i]!='6')&&(tel[i]!='7')&&(tel[i]!='8')&&(tel[i]!='9'))
test++;
}
if ((tel[0]!='1')&&(tel[0]!='0'))
test++;

return test;
}

int verif_idd_etudiant(char id[])
{
int test=-1;
int i,n;
n=strlen(id);
printf("\nn est %d ",n);
if (strlen(id)!=8)
test++;

return test;
}
int verif_dn_etudiant(date dn)
{
int test=-1;
if (dn.annee>=2004)
test++;

}
int tache_etudiant(char classe[])
{
int n=0;
FILE *f=NULL;
etudiant e2;
f=fopen("utilisateur.txt","r");
if(f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %s \n",e2.id,e2.cin,e2.nom,e2.prenom,e2.sexe,e2.email,e2.tel,&e2.etage,&e2.chambre,&e2.dn.jours,&e2.dn.mois,&e2.dn.annee,e2.classe)!=EOF)
{
if ((strcmp(classe,e2.classe)==0))
n++;
}
fclose(f);
}
return (n);
}




















