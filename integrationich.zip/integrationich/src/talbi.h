#include <gtk/gtk.h>

typedef struct date2
{
int jours;
int mois;
int annee;
}
date2;

typedef struct stock
{
char id[9];
char quantite[9];
char nom[30];
char emballage[30];
char prix[30];
date2 dn;
char origine[30];
}stock;

void afficher_stock(GtkWidget *liste);
void supprimer_stock(stock t);
void modifier( stock t);
void afficher_stockk(GtkWidget *liste);
void vider(GtkWidget *liste);
int idexisteee(char idhela[]);
