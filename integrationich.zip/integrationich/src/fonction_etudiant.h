#include <gtk/gtk.h>
int verif_foyer(char log[],char Pw[]);
typedef struct date
{
int jours;
int mois;
int annee;


}date;
typedef struct etudiant
{
char id[9];
char cin[9];
char nom[30];
char prenom[30];
char sexe[30];
char email[30];
char tel[30];
int etage;
int chambre;
date dn;
char classe[30];
}etudiant;
int verif_id_foyer(char id[]);
int verif_idd_foyer (char email[]);
int verif_cin_foyer (char email[]);
int verif_email_foyer (char email[]);
int verif_tel_foyer (char email[]);
int tache_etudiant(char classe[]);
