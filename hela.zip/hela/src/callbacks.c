#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "talbi.h"
#include <string.h>
int x;
void
on_button_A_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeview_H_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
stock t;
GtkTreeIter iter;
gchar* id;
gchar* quantite;
gchar* nom;
gchar* emballage;
gchar* prix;





gint* jours;
gint* mois;
gint* annee;
gchar* origine;
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model, &iter, path))
{
gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &id,1, &quantite, 2, &nom, 3, &emballage, 4, &prix, 5 , &jours, 6 , &mois, 7 , &annee, 8 , &origine, -1);
strcpy(t.id,id);
strcpy(t.quantite,quantite);

strcpy(t.nom,nom);
strcpy(t.origine,origine);
strcpy(t.emballage,emballage);
strcpy(t.prix,prix);

t.dn.jours=jours;
t.dn.mois=mois;
t.dn.annee=annee;
supprimer_stock(t);

afficher_stock(treeview);

}
}



void
on_button_E_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *xd;
xd=create_recherche_stock();
gtk_widget_show(xd);
}


void
on_button_C_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowajout_stock;

windowajout_stock=create_ajout_stock();
gtk_widget_show(windowajout_stock);
}




void
on_radiobutton_H_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=1;
printf("\nla valeur de x est %d",x);
}
}


void
on_radiobutton_T_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=2;
printf("\nla valeur de x est %d",x);
}
}


void
on_button_G_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *menu;
menu=create_menu();
gtk_widget_show (menu);
}




void
on_button_I_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_J_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE *f=NULL;
GtkWidget *info5,*id,*nom,*prix,*calendar,*quantite,*origine,*ctrll;
char nom1[30];
char id1[9];
char origine1[30];
char emballage1[30];
char quantite1[9];
int jours1,mois1,annee1;
char prix2[30];

//-------association-----------------
calendar = lookup_widget(objet_graphique, "calendar");
nom = lookup_widget (objet_graphique, "entry_22");
origine = lookup_widget (objet_graphique, "combobox_origine");
id = lookup_widget (objet_graphique, "entry_11");
quantite = lookup_widget (objet_graphique, "entry_33");
prix=lookup_widget(objet_graphique,"entry_44");

///////////////////////////
gtk_calendar_get_date(GTK_CALENDAR(calendar),&jours1,&mois1,&annee1);
strcpy(nom1, gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(quantite1, gtk_entry_get_text(GTK_ENTRY(quantite)));
strcpy(prix2, gtk_entry_get_text(GTK_ENTRY(prix)));
strcpy(origine1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(origine)));
if (x==1)
{
strcpy(emballage1,"emballee");
}
 else 

{
strcpy(emballage1,"non_emballee");
}



mois1+=1;

printf("\n%s",nom1);

printf("\n%s",id1);
printf("\n%s",quantite1);
printf("\n%s",emballage1);
printf("\n%d",jours1);
printf("\n%d",mois1);
printf("\n%d",annee1);
printf("\n%s",origine1);
printf("\n%s",prix2);




//ouvrir le fichier 
f=fopen("utilisateur.txt","a+");
if(f!=NULL)
{
//controle
if (idexisteee(id1)==1)
    {ctrll= lookup_widget(objet_graphique,"idident");
gtk_label_set_text(GTK_LABEL(ctrll),"ce id existe deja😔");}

else {

//ecrire dans le fichier
fprintf(f,"%s %s %s %s %s %d %d %d %s\n",id1,quantite1,nom1,emballage1,prix2,jours1,mois1,annee1,origine1);
fclose(f);
info5=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"produit ajouté avec succées!");
switch (gtk_dialog_run(GTK_DIALOG(info5)))
{
case GTK_RESPONSE_OK:
gtk_widget_destroy(info5);
break;

}

}}




}





void
on_button_K_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *identifiant,*info,*info2;

char idhah[20];
int test=0;
identifiant = lookup_widget (objet_graphique,"entry_88");

strcpy(idhah, gtk_entry_get_text(GTK_ENTRY(identifiant)));

printf("\n%s",idhah);
GtkWidget *windowmodifier;
stock t2;

FILE *f,*g;
f=fopen("utilisateur.txt","r");
g=fopen("tmp22.txt","w");
if ((f!=NULL) )
{
while (fscanf(f,"%s %s %s %s %s  %d %d %d  %s \n",t2.id,t2.quantite,t2.nom,t2.emballage,t2.prix,&t2.dn.jours,&t2.dn.mois,&t2.dn.annee,t2.origine)!=EOF)
{
if (strcmp(idhah,t2.id)==0)
{
test=1;
fprintf(g,"%s %s %s %s %s  %d %d %d  %s \n",t2.id,t2.quantite,t2.nom,t2.emballage,t2.prix,t2.dn.jours,t2.dn.mois,t2.dn.annee,t2.origine);
info=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"produit trouvé avec succés!");
switch (gtk_dialog_run(GTK_DIALOG(info)))
{
case GTK_RESPONSE_OK:
gtk_widget_destroy(info);
break;
}
}



}
}
fclose(f);
fclose(g);



if (test==0)
{
info2=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"pas de produit avec un tel ID");
switch (gtk_dialog_run(GTK_DIALOG(info2)))
{
case GTK_RESPONSE_OK:
gtk_widget_destroy(info2);
break;

}
}
////// iniiiiiiiiiit

stock t3;
GtkWidget *nom,*radio3,*radio4,*calendar,*id,*origine,*quantite,*emballage,*prix,*spin_jours,*spin_mois,*spin_annee;
FILE *q=NULL;
char m[200][200]={"vegetal","animal"};
char m1[200][200]={"emballee","non_emballee"};
int i=0;
int j=0;
q=fopen("tmp22.txt","r");
fscanf(q,"%s %s %s %s %s  %d %d %d  %s \n",t3.id,t3.quantite,t3.nom,t3.emballage,t3.prix,&t3.dn.jours,&t3.dn.mois,&t3.dn.annee,t3.origine);
nom = lookup_widget (objet_graphique,"entry_88");
gtk_entry_set_text(nom,t3.id);
nom = lookup_widget (objet_graphique,"entry_111");
gtk_entry_set_text(nom,t3.quantite);
nom = lookup_widget (objet_graphique,"entry_99");
gtk_entry_set_text(nom,t3.nom);

nom = lookup_widget (objet_graphique,"entry_222");
gtk_entry_set_text(nom,t3.prix);
///////// calendar //////////

t3.dn.mois-=1;



while ((j<2) && (strcmp(m1[j],t3.emballage))!=0)
{
j=j+1;}
emballage = lookup_widget (objet_graphique, "combobox_444");
gtk_combo_box_set_active(GTK_COMBO_BOX(emballage),j);
while ((i<2) && (strcmp(m[i],t3.origine))!=0)
{
i=i+1;}

origine = lookup_widget (objet_graphique, "combobox_333");
gtk_combo_box_set_active(GTK_COMBO_BOX(origine),i);

spin_jours=lookup_widget(objet_graphique,"spinbutton_X");
spin_mois=lookup_widget(objet_graphique,"spinbutton_Y");
spin_annee=lookup_widget(objet_graphique,"spinbutton_Z");
gtk_spin_button_set_value(spin_jours,t3.dn.jours);
gtk_spin_button_set_value(spin_mois,t3.dn.mois);
gtk_spin_button_set_value(spin_annee,t3.dn.annee);
}





void
on_button_L_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
stock t;
GtkWidget *info3,*id2,*nom2,*emballage2,*prix2,*quantite2,*origine2,*spin_jours,*spin_mois,*spin_annee;
char nom1[30];
char id1[9];
char origine1[30];
char emballage4[30];
char quantite1[9];
int jours1,mois1,annee1;
char prix1[30];

//////////////////////////////////////////
nom2 = lookup_widget (objet_graphique, "entry_99");
origine2 = lookup_widget (objet_graphique, "combobox_333");
emballage2 = lookup_widget (objet_graphique, "combobox_444");
id2 = lookup_widget (objet_graphique, "entry_88");
quantite2 = lookup_widget (objet_graphique, "entry_111");
prix2=lookup_widget(objet_graphique,"entry_222");
spin_jours=lookup_widget(objet_graphique,"spinbutton_X");
spin_mois=lookup_widget(objet_graphique,"spinbutton_Y");
spin_annee=lookup_widget(objet_graphique,"spinbutton_Z");


///////////////////////////

strcpy(nom1, gtk_entry_get_text(GTK_ENTRY(nom2)));
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(id2)));
strcpy(quantite1, gtk_entry_get_text(GTK_ENTRY(quantite2)));
strcpy(prix1, gtk_entry_get_text(GTK_ENTRY(prix2)));
strcpy(origine1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(origine2)));
strcpy(emballage4,gtk_combo_box_get_active_text(GTK_COMBO_BOX(emballage2)));
jours1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_jours));
mois1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_mois));
annee1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_annee));

strcpy(t.quantite,quantite1);
strcpy(t.id,id1);
strcpy(t.nom,nom1);
strcpy(t.emballage,emballage4);
strcpy(t.prix,prix1);
t.dn.jours=jours1;
t.dn.mois=mois1;
t.dn.annee=annee1;
strcpy(t.origine,origine1);

printf("\n%s",t.quantite);
printf("\n%s",t.id);
printf("\n%s",t.nom);
printf("\n%s",t.emballage);
printf("\n%s",t.prix);
printf("\n%d",t.dn.jours);
printf("\n%d",t.dn.mois);
printf("\n%d",t.dn.annee);

printf("\n%s\n",t.origine);





modifier(t);

info3=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"modification effectuée avec succées!");
switch (gtk_dialog_run(GTK_DIALOG(info3)))
{
case GTK_RESPONSE_OK:
gtk_widget_destroy(info3);
break;

}

}


void
on_button_M_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *lol,*info6,*info7,*treeviews,*windowEspacestock1;

char lol1[20];
int test1=0;
lol = lookup_widget (objet_graphique,"entry_777");
strcpy(lol1, gtk_entry_get_text(GTK_ENTRY(lol)));

stock t4;

FILE *f1,*g1;
f1=fopen("utilisateur.txt","r");
g1=fopen("tmp77.txt","w");
if ((f1!=NULL) )
{
while (fscanf(f1,"%s %s %s %s %s  %d %d %d  %s \n",t4.id,t4.quantite,t4.nom,t4.emballage,t4.prix,&t4.dn.jours,&t4.dn.mois,&t4.dn.annee,t4.origine)!=EOF)
{
if (strcmp(lol1,t4.id)==0)
{
test1=1;
fprintf(g1,"%s %s %s %s %s  %d %d %d  %s \n",t4.id,t4.quantite,t4.nom,t4.emballage,t4.prix,t4.dn.jours,t4.dn.mois,t4.dn.annee,t4.origine);
info6=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"stock trouvé avec succés!");
switch (gtk_dialog_run(GTK_DIALOG(info6)))
{
case GTK_RESPONSE_OK:


gtk_widget_destroy(info6);
break;
}

}



}
}
fclose(f1);
fclose(g1);



if (test1==0)
{
info7=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"pas de stock avec un tel ID");
switch (gtk_dialog_run(GTK_DIALOG(info7)))
{
case GTK_RESPONSE_OK:
gtk_widget_destroy(info7);
////////////////////////////////////////////////////////////
break;

}

}
else if (test1==1)

{
windowEspacestock1=create_cherche();
gtk_widget_show(windowEspacestock1);
treeviews=lookup_widget(windowEspacestock1,"treeviews");
//vider(treeview21);
afficher_stockk(treeviews);

}
}


void
on_button_N_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_button_D_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
{

GtkWidget *windowmodif_stock;

windowmodif_stock=create_modif_stock();
gtk_widget_show(windowmodif_stock);
}
}


void
on_button_F_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview2;
treeview2=lookup_widget(button,"treeview_H");
afficher_stock(treeview2);
}


void
on_button_O_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *menu;
menu=create_menu();
gtk_widget_show (menu);
}


void
on_button_P_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *menu;
menu=create_menu();
gtk_widget_show (menu);
}


void
on_button_Q_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entry_999, *output, *ctrll;
int hela;
stock t;
entry_999=lookup_widget(button,"entry_999");
strcpy(t.id,gtk_entry_get_text(GTK_ENTRY(entry_999)));
//controle
if (idexisteee(t.id)==0)
    {ctrll= lookup_widget(button,"label_1002");
gtk_label_set_text(GTK_LABEL(ctrll),"pas de produit avec un tel id😔");}
else 
{


hela=repture_stock(t.id);
if (hela==1)
{
  output= lookup_widget(button,"label_1000");
 gtk_label_set_text(GTK_LABEL(output),"produit en stock 😎️");}
else
 {output= lookup_widget(button,"label_1000");
gtk_label_set_text(GTK_LABEL(output),"produit en repture de stock");}

}
}

void
on_button_R_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dash;
dash=create_dash();
gtk_widget_show (dash);
}


void
on_button_S_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *menu;
menu=create_menu();
gtk_widget_show (menu);
}

