#include <gtk/gtk.h>


void
on_button_A_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_H_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_E_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_C_clicked                    (GtkButton       *button,
                                        gpointer         user_data);


void
on_radiobutton_H_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_T_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_G_clicked                    (GtkButton       *button,
                                        gpointer         user_data);



void
on_button_I_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_J_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_K_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_L_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_M_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_N_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_D_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_F_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_O_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_P_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_Q_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_R_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_S_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
