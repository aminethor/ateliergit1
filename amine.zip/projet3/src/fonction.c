#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include "fonction.h"
#include <string.h>


enum 
{
ENOM,
EPRENOM,
ELOGIN,
EPASSWORD,
EROLE,
EID,
EDATE,
ESEXE,
COLUMNS,
};

void ajouter_i(char nom_fichier[],utilisateur u)
{
FILE *f=NULL;
//ouvrir le fichier
f=fopen(nom_fichier,"a+");    
if (f!=NULL){
//ecrire dans le fichier
fprintf(f,"%s %s %s %s %d %s %s %s\n",u.nom,u.prenom,u.login,u.password,u.role,u.id,u.date,u.sexe);
fclose(f);}
else
printf("impossible d'ouvrir le fichier 'user.txt' \n");
}



/*void afficher(char nom_fichier[100])
{
char Nom[100];
char Prenom[100];
char Log[100];
char Passw[100];
int Role;
char ID[100];
FILE *f=NULL;
f=fopen(nom_fichier,"r");   
printf("les donnees des utilisateurs sont:\n");
if (f!=NULL){
while(fscanf(f,"%s %s %s %s %d %s",Nom,Prenom,Log,Passw,&Role,ID)!=EOF)
{ 
printf("%s %s %s %s %d %s\n",Nom,Prenom,Log,Passw,Role,ID);
}
}
else
printf("impossible d'ouvrir le fichier 'user.txt' \n");
}*/



void afficher_u(GtkWidget *liste)
{
GtkCellRenderer  *renderer;
GtkTreeViewColumn  *column;
GtkTreeIter  iter;
GtkListStore  *store;
char nom[100];
char prenom[100];
char login[100];
char password[100];
int role;
char id[100];
char date[100];
char sexe[100];
FILE *f=NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);    
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("login",renderer,"text",ELOGIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("password",renderer,"text",EPASSWORD,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("role",renderer,"text",EROLE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("date",renderer,"text",EDATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);   
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);          
}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("user.txt","r");

if (f!=NULL)
{
while (fscanf(f,"%s %s %s %s %d %s %s %s",nom,prenom,login,password,&role,id,date,sexe)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,ENOM,nom,EPRENOM,prenom,ELOGIN,login,EPASSWORD,password,EROLE,role,EID,id,EDATE,date,ESEXE,sexe,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}

void rechercher_k(GtkWidget *liste,char Id[])
{
GtkCellRenderer  *renderer;
GtkTreeViewColumn  *column;
GtkTreeIter  iter;
GtkListStore  *store;
char nom[100];
char prenom[100];
char login[100];
char password[100];
int role;
char id[100];
char date[100];
char sexe[100];
FILE *f=NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);    
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("login",renderer,"text",ELOGIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("password",renderer,"text",EPASSWORD,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("role",renderer,"text",EROLE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);     
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("date",renderer,"text",EDATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);   
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);      
}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("user.txt","r");

if (f!=NULL)
{
while (fscanf(f,"%s %s %s %s %d %s %s %s",nom,prenom,login,password,&role,id,date,sexe)!=EOF)
{   if (strcmp(id,Id)==0)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,ENOM,nom,EPRENOM,prenom,ELOGIN,login,EPASSWORD,password,EROLE,role,EID,id,EDATE,date,ESEXE,sexe,-1);}
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}

void modifier_no(char nom_fichier[],utilisateur u)
{
utilisateur u1;
char Nom[100];
char Prenom[100];
char Log[100];
char Passw[100];
int Role;
char iden[100],Date[100],Sexe[100];
FILE *f=NULL;
FILE *fi=NULL;
f=fopen(nom_fichier,"r");
fi=fopen("tmp.txt","w");
if (f!=NULL){
if (fi!=NULL)
{
while(fscanf(f,"%s %s %s %s %d %s %s %s\n",u1.nom,u1.prenom,u1.login,u1.password,&(u1.role),u1.id,u1.date,u1.sexe)!=EOF)
{
if (strcmp(u.id,u1.id)==0)
fprintf(fi,"%s %s %s %s %d %s %s %s\n",u.nom,u.prenom,u.login,u.password,u.role,u.id,u.date,u.sexe);
else
fprintf(fi,"%s %s %s %s %d %s %s %s\n",u1.nom,u1.prenom,u1.login,u1.password,u1.role,u1.id,u1.date,u1.sexe);
}
}
else
printf("erreur");
}
else
printf("\n utilisateur inexistant \n");
fclose(f);
fclose(fi);
remove(nom_fichier);
rename("tmp.txt",nom_fichier);
}





int chercher(char nom_fichier[],char Id[])
{
char Nom[100];
char Prenom[100];
char Log[100];
char Passw[100];
int Role,test=0;
char ID[100],Date[100],Sexe[100];
FILE *f=NULL;
f=fopen(nom_fichier,"r");
if (f!=NULL) 
{
while(fscanf(f,"%s %s %s %s %d %s %s %s",Nom,Prenom,Log,Passw,&Role,ID,Date,Sexe)!=EOF)
{ 
if (strcmp(ID,Id)==0)
{
     test=1;
     return test;}
}
fclose(f);
return test;
}
}



void supprimer(char nom_fichier[],char Id[])
{
char Nom[100];
char Prenom[100];
char Log[100],fichier[100];
char Passw[100];
int Role;
char ID[100],Date[100],Sexe[100];
FILE *f=NULL;
FILE *fi=NULL;
f=fopen(nom_fichier,"r");
if (f==NULL)
printf("erreur");
else
{
fi=fopen("tmp.txt","w");
if (fi==NULL)
printf("erreur");
else
{
while (fscanf(f,"%s %s %s %s %d %s %s %s",Nom,Prenom,Log,Passw,&Role,ID,Date,Sexe)!=EOF)
{
if (strcmp(ID,Id)!=0)
fprintf(fi,"%s %s %s %s %d %s %s %s\n",Nom,Prenom,Log,Passw,Role,ID,Date,Sexe);
}
fclose(f);
fclose(fi);
}
remove(nom_fichier);
rename("tmp.txt",nom_fichier);
}
}
void stat()
{
FILE *f=NULL;
int jour,heure,num_capteur;
float valeur_debit;
f=fopen("debit.txt","r");
printf("les etages contenant des pannes sont:\n");
if (f!=NULL)
{
while (fscanf(f,"%d %d %d %f",&jour,&heure,&num_capteur,&valeur_debit)!=EOF)
{
if (valeur_debit>30)
printf("l'etage %d à la %d ieme heure le jour %d\n",num_capteur,heure,jour);  
}
}
}




void suppr(utilisateur u)
{
utilisateur u1;
FILE *f=NULL,*g=NULL;
f=fopen("user.txt","r");
g=fopen("user1.txt","w");
if ((f!=NULL) && (g!=NULL))
{
while (fscanf(f,"%s %s %s %s %d %s %s %s",&(u1.nom),&(u1.prenom),&(u1.login),&(u1.password),u1.role,&(u1.id),u1.date,u1.sexe)!=EOF)
{
if (strcmp(u.nom,u1.nom)!=0 || strcmp(u.prenom,u1.prenom)!=0 || strcmp(u.login,u1.login)!=0 || strcmp(u.password,u1.password)!=0 || u.role!=u1.role || strcmp(u.id,u1.id)!=0 || strcmp(u.date,u1.date)!=0 || strcmp(u.sexe,u1.sexe)!=0)

                 fprintf(g,"%s %s %s %s %d %s %s %s",u1.nom,u1.prenom,u1.login,u1.password,u1.role,u1.id,u1.date,u1.sexe);

}
fclose(f);
fclose(g);
}

remove("user.txt");
rename("user1.txt","user.txt");
}







void rechercher_homme(GtkWidget *liste)
{
GtkCellRenderer  *renderer;
GtkTreeViewColumn  *column;
GtkTreeIter  iter;
GtkListStore  *store;
char nom[100];
char prenom[100];
char login[100];
char password[100];
int role;
char id[100];
char date[100];
char sexe[100];
FILE *f=NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);    
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("login",renderer,"text",ELOGIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("password",renderer,"text",EPASSWORD,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("role",renderer,"text",EROLE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);     
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("date",renderer,"text",EDATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);   
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);      
}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("user.txt","r");

if (f!=NULL)
{
while (fscanf(f,"%s %s %s %s %d %s %s %s",nom,prenom,login,password,&role,id,date,sexe)!=EOF)
{   if (strcmp(sexe,"Homme")==0)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,ENOM,nom,EPRENOM,prenom,ELOGIN,login,EPASSWORD,password,EROLE,role,EID,id,EDATE,date,ESEXE,sexe,-1);}
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}


void rechercher_femme(GtkWidget *liste)
{
GtkCellRenderer  *renderer;
GtkTreeViewColumn  *column;
GtkTreeIter  iter;
GtkListStore  *store;
char nom[100];
char prenom[100];
char login[100];
char password[100];
int role;
char id[100];
char date[100];
char sexe[100];

FILE *f=NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);    
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("login",renderer,"text",ELOGIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("password",renderer,"text",EPASSWORD,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("role",renderer,"text",EROLE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);     
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("date",renderer,"text",EDATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);   
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);      
}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("user.txt","r");

if (f!=NULL)
{
while (fscanf(f,"%s %s %s %s %d %s %s %s",nom,prenom,login,password,&role,id,date,sexe)!=EOF)
{   if (strcmp(sexe,"Femme")==0)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,ENOM,nom,EPRENOM,prenom,ELOGIN,login,EPASSWORD,password,EROLE,role,EID,id,EDATE,date,ESEXE,sexe,-1);}
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}






int chercher_homme(char ch[])
{
FILE *f=NULL;
char nom[100];
char prenom[100];
char login[100];
char password[100];
int role;
char id[100];
char date[100];
char sexe[100];
f=fopen("user.txt","r");
int test_ve=0;
if (f!=NULL)
{
while (fscanf(f,"%s %s %s %s %d %s %s %s",nom,prenom,login,password,&role,id,date,sexe)!=EOF)
{   
if (strcmp(sexe,"Homme")==0)
{
test_ve=1;
break;
}
}
fclose(f);
}
return test_ve;
}


int chercher_femme(char ch[])
{
FILE *f=NULL;
char nom[100];
char prenom[100];
char login[100];
char password[100];
int role;
char id[100];
char date[100];
char sexe[100];
f=fopen("user.txt","r");
int test_ve=0;
if (f!=NULL)
{
while (fscanf(f,"%s %s %s %s %d %s %s %s",nom,prenom,login,password,&role,id,date,sexe)!=EOF)
{   
if (strcmp(sexe,"Femme")==0)
{
test_ve=1;
break;
}
}
fclose(f);
}
return test_ve;
}


