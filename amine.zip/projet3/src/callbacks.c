#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <gtk/gtk.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
int to[3]={0,0,0};
int xo=1;

void
on_checkbutton2_aj_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
   if (gtk_toggle_button_get_active(togglebutton))
{
to[0]=1;
}  
else
{
to[0]=0;
}
}




void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
  if (gtk_toggle_button_get_active(togglebutton))
{
to[2]=1;
}  
else
{
to[2]=0;
}
}


void
on_button5_ok_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
if (to[1]==1)
{
GtkWidget *modif;
GtkWidget *Gestion;
Gestion=lookup_widget(objet,"Gestion");
gtk_widget_destroy(Gestion);
modif=lookup_widget(objet,"ajout_modif");
modif=create_ajout_modif();
gtk_widget_show(modif);
to[1]=0;
}
   else if (to[0]==1)
{
   GtkWidget *Gestion;
   Gestion=lookup_widget(objet,"Gestion");
   gtk_widget_destroy(Gestion);
   GtkWidget *ajout;
   ajout=lookup_widget(objet,"ajout_modif");
   ajout=create_ajout_modif();
   gtk_widget_show(ajout);
 to[0]=0; 
}
 else if (to[2]==1)
{
 GtkWidget *Gestion;
   Gestion=lookup_widget(objet,"Gestion");
   gtk_widget_destroy(Gestion);
   GtkWidget *delete;
   delete=lookup_widget(objet,"DELETE");
   delete=create_DELETE();
   gtk_widget_show(delete);
to[2]=0;   
}
}


void
on_button6_recher_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
   char ch[20]="user.txt",m[100]="utilisateur inexistant",ch2[100];
   char ID[100],Nom[100],Prenom[100],Log[100],Passw[100],iden[100];
   GtkWidget *mom,*mom1;
   int Role,test;
   FILE *f=NULL;
   f=fopen(ch,"r");
   utilisateur u;
   GtkWidget *Id;
   Id=lookup_widget(objet,"entry3_cherid");
   strcpy(ID,gtk_entry_get_text(GTK_ENTRY(Id)));
   test=chercher(ch,ID);
   if (test==1)
   {
   GtkWidget *treeview1_user;
   treeview1_user=lookup_widget(objet,"treeview1_user"); 
   rechercher_k(treeview1_user,ID);
   mom=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"utilisateur trouvé avec succés!");
switch (gtk_dialog_run(GTK_DIALOG(mom)))
{
case GTK_RESPONSE_OK:
gtk_widget_destroy(mom);
break;
   }
}
   else
   {
    mom1=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"pas d'utilisateurs avec un tel ID");
switch (gtk_dialog_run(GTK_DIALOG(mom1)))
{
case GTK_RESPONSE_OK:
gtk_widget_destroy(mom1);
break;
   }
}
}


void
on_button7_ajou_clicked                (GtkWidget       *objet, 
                                        gpointer         user_data)
{
  char ch[]="user.txt";
  GtkWidget *Gestion;
  GtkWidget *combobox1_choice;
  GtkWidget *u;
  GtkWidget *pw;
  GtkWidget *n;
  GtkWidget *p;
  GtkWidget *i;
  GtkWidget *Rol;
  GtkWidget *calendar;
  GtkWidget *ajout,*min1;
  char u1[100],passw[100],N[100],P[100];
  char I[100],D[100],S[100];
  int r,jour,mois,annee,Mois1;
  char j[100],m[100],an[100];
  utilisateur a;
  GtkWidget *treeview1_user;
  combobox1_choice=lookup_widget(objet,"combobox1_sE");
  calendar=lookup_widget(objet,"calendar1_date");
  n=lookup_widget(objet,"entry4_n");
  p=lookup_widget(objet,"entry5_p");
  u=lookup_widget(objet,"entry6_u");
  pw=lookup_widget(objet,"entry7_p");
  i=lookup_widget(objet,"entry8_id");
  Rol=lookup_widget(objet,"spinbutton2_Ro");
  strcpy(N,gtk_entry_get_text(GTK_ENTRY(n)));
  strcpy(P,gtk_entry_get_text(GTK_ENTRY(p)));
  strcpy(u1,gtk_entry_get_text(GTK_ENTRY(u)));
  strcpy(passw,gtk_entry_get_text(GTK_ENTRY(pw)));
  strcpy(I,gtk_entry_get_text(GTK_ENTRY(i)));
  strcpy(S,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1_choice)));
  gtk_calendar_get_date(GTK_CALENDAR(calendar),&jour,&mois,&annee);
  Mois1=mois+1;
  sprintf(j,"%d",jour);
  sprintf(m,"%d",Mois1);
  sprintf(an,"%d",annee);
  strcat(an,"/");
  strcat(an,m);
  strcat(an,"/");
  strcat(an,j);
  strcpy(D,an);
  strcpy(a.nom,N);
  strcpy(a.prenom,P);
  strcpy(a.login,u1);
  strcpy(a.password,passw);
  strcpy(a.id,I);
  strcpy(a.date,D);
  strcpy(a.sexe,S);
  a.role=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Rol));
  ajouter_i(ch,a);
  ajout=lookup_widget(objet,"ajout_modif");
  gtk_widget_destroy(ajout);
  Gestion=lookup_widget(objet,"Gestion");
  Gestion=create_Gestion();
  gtk_widget_show(Gestion);
  treeview1_user=lookup_widget(Gestion,"treeview1_user"); 
  afficher_u(treeview1_user);
  min1=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"ajout avec succés!");
switch (gtk_dialog_run(GTK_DIALOG(min1)))
{
case GTK_RESPONSE_OK:
gtk_widget_destroy(min1);
break;
}
}

void
on_button8_modif_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
  char ch[]="user.txt";
  GtkWidget *us;
  GtkWidget *pasw;
  GtkWidget *no;
  GtkWidget *pr;
  GtkWidget *Ro;
  GtkWidget *ide;
  GtkWidget *ajout;
  GtkWidget *Gestion;
  GtkWidget *combobox1_choice;
  GtkWidget *calendar,*my1;
  int jour,mois,annee,Mois1;
  char u1[20],passw[20],N[20],P[20],ID[100],m[100];
  char j[100],M[100],an[100],S[100],D[100];
  char Date[100];
  utilisateur a;
  GtkWidget *treeview1_user; 
  no=lookup_widget(objet,"entry4_n");
  pr=lookup_widget(objet,"entry5_p");
  us=lookup_widget(objet,"entry6_u");
  pasw=lookup_widget(objet,"entry7_p");
  ide=lookup_widget(objet,"entry8_id");
  Ro=lookup_widget(objet,"spinbutton2_Ro");
  combobox1_choice=lookup_widget(objet,"combobox1_sE");
  calendar=lookup_widget(objet,"calendar1_date");
  strcpy(N,gtk_entry_get_text(GTK_ENTRY(no)));
  strcpy(P,gtk_entry_get_text(GTK_ENTRY(pr)));
  strcpy(u1,gtk_entry_get_text(GTK_ENTRY(us)));
  strcpy(passw,gtk_entry_get_text(GTK_ENTRY(pasw)));
  strcpy(ID,gtk_entry_get_text(GTK_ENTRY(ide)));
  strcpy(S,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1_choice)));
  gtk_calendar_get_date(GTK_CALENDAR(calendar),&jour,&mois,&annee);
  a.role=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Ro));
  Mois1=mois+1;
  sprintf(j,"%d",jour);
  sprintf(M,"%d",Mois1);
  sprintf(an,"%d",annee);
  strcat(an,"/");
  strcat(an,M);
  strcat(an,"/");
  strcat(an,j);
  strcpy(D,an);
  strcpy(a.nom,N);
  strcpy(a.prenom,P);
  strcpy(a.login,u1);
  strcpy(a.password,passw);
  strcpy(a.id,ID);
  strcpy(a.date,D);
  strcpy(a.sexe,S);
  modifier_no(ch,a);
  ajout=lookup_widget(objet,"ajout_modif");
  gtk_widget_destroy(ajout);
  Gestion=lookup_widget(objet,"Gestion");
  Gestion=create_Gestion();
  gtk_widget_show(Gestion);
  treeview1_user=lookup_widget(Gestion,"treeview1_user"); 
  afficher_u(treeview1_user);
  my1=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"modification avec succés!");
switch (gtk_dialog_run(GTK_DIALOG(my1)))
{
case GTK_RESPONSE_OK:
gtk_widget_destroy(my1);
break;
}
}




void
on_button10_Delete_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
  char ch[20]="user.txt";
  int test;
  GtkWidget *ide,*no1,*no2;
  GtkWidget *delete;
  GtkWidget *Gestion;
  GtkWidget *treeview1_user;
  char ID[100];
  ide=lookup_widget(objet,"entry11_Del");
  strcpy(ID,gtk_entry_get_text(GTK_ENTRY(ide)));
  test=chercher(ch,ID);
  if (test==1)
  {
  supprimer(ch,ID);
  delete=lookup_widget(objet,"DELETE");
  gtk_widget_destroy(delete);
  Gestion=lookup_widget(objet,"Gestion");
  Gestion=create_Gestion();
  gtk_widget_show(Gestion);
  treeview1_user=lookup_widget(Gestion,"treeview1_user"); 
  afficher_u(treeview1_user);
   no1=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"utilisateur supprimé avec succés!");
switch (gtk_dialog_run(GTK_DIALOG(no1)))
{
case GTK_RESPONSE_OK:
gtk_widget_destroy(no1);
break;
  }
}
  else
  {
   no2=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"Id n'existe pas!");
switch (gtk_dialog_run(GTK_DIALOG(no2)))
{
case GTK_RESPONSE_OK:
gtk_widget_destroy(no2);
break;
  }
  }
}


void
on_treeview1_user_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
  
 GtkTreeIter iter;
 gchar* nom;
 gchar* prenom;
 gchar* login;
 gchar* password;
 gint* role;
 gchar* id;
 gchar* date;
 gchar* sexe;
 utilisateur u;
 GtkTreeModel *model=gtk_tree_view_get_model(treeview);
 if (gtk_tree_model_get_iter(model,&iter,path))
 {
  gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&nom,1,&prenom,2,&login,3,&password,4,&role,5,&id,6,&date,7,&sexe,-1);
  strcpy(u.nom,nom);
  strcpy(u.prenom,prenom);
  strcpy(u.login,login);
  strcpy(u.password,password);
  strcpy(u.id,id);
  u.role=role;
  strcpy(u.date,date);
  strcpy(u.sexe,sexe);
  supprimer("user.txt",u.id);
  afficher_u(treeview);
  
}
}





void
on_button1_aff_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *treeview1_user;
   treeview1_user=lookup_widget(objet,"treeview1_user"); 
   afficher_u(treeview1_user);
}


void
on_checkbutton1_xo_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if (gtk_toggle_button_get_active(togglebutton))
{
to[1]=1;
} 
else
{
to[1]=0;
}
}

void
on_button1_aq_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *Gestion;
    GtkWidget *ajout;
    GtkWidget *treeview1_user;
    ajout=lookup_widget(button,"ajout_modif");
    gtk_widget_destroy(ajout);
    Gestion=lookup_widget(button,"Gestion");
    Gestion=create_Gestion();
    gtk_widget_show(Gestion);
    treeview1_user=lookup_widget(Gestion,"treeview1_user"); 
    afficher_u(treeview1_user);
}


void
on_button2_kn_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *Gestion;
    GtkWidget *Del;
    GtkWidget *treeview1_user;
    Del=lookup_widget(button,"DELETE");
    gtk_widget_destroy(Del);
    Gestion=lookup_widget(button,"Gestion");
    Gestion=create_Gestion();
    gtk_widget_show(Gestion);
    treeview1_user=lookup_widget(Gestion,"treeview1_user"); 
    afficher_u(treeview1_user);
}





void
on_button1_ax_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
char texte[100],Nom[100],Prenom[100],Log[100],Passw[100],iden[100],ch[100]="utilisateur inexistant",m[100];
GtkWidget *ID,*mine2,*mine3;
GtkWidget *r;
GtkWidget *entry4;
GtkWidget *entry5;
GtkWidget *entry6;
GtkWidget *entry7;
char Iden[100],Date[100],Sexe[100];
int Role,test;
GtkWidget* output;
utilisateur u;
FILE *f=NULL;
f=fopen("user.txt","r");
ID=lookup_widget(objet,"entry8_id");
r=lookup_widget(objet,"spinbutton2_Ro");
strcpy(Iden,gtk_entry_get_text(GTK_ENTRY(ID)));
test=chercher("user.txt",Iden);
if (test==1)
{
if (f!=NULL) 
{
while(fscanf(f,"%s %s %s %s %d %s %s %s",Nom,Prenom,Log,Passw,&Role,iden,Date,Sexe)!=EOF)
{
if (strcmp(iden,Iden)==0)
{
mine2=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"utilisateur trouvé avec succés!");
switch (gtk_dialog_run(GTK_DIALOG(mine2)))
{
case GTK_RESPONSE_OK:
gtk_widget_destroy(mine2);
break;
}
strcpy(u.nom,Nom);
strcpy(u.prenom,Prenom);
strcpy(u.login,Log);
strcpy(u.password,Passw);
strcpy(u.id,iden);
u.role=Role;
entry4=lookup_widget(objet,"entry4_n");
entry5=lookup_widget(objet,"entry5_p");
entry6=lookup_widget(objet,"entry6_u");
entry7=lookup_widget(objet,"entry7_p");
gtk_entry_set_text(GTK_ENTRY(ID),u.id);
gtk_entry_set_text(GTK_ENTRY(entry7),u.password);
gtk_entry_set_text(GTK_ENTRY(entry6),u.login);
gtk_entry_set_text(GTK_ENTRY(entry5),u.prenom);
gtk_entry_set_text(GTK_ENTRY(entry4),u.nom);
gtk_spin_button_set_value(r,u.role);
break;
}
}
}
to[1]=0;
}
else
{
mine3=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"pas d'utilisateurs avec un tel ID!");
switch (gtk_dialog_run(GTK_DIALOG(mine3)))
{
case GTK_RESPONSE_OK:
gtk_widget_destroy(mine3);
break;
}
}
}





void
on_button2_AFf_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget* output;
FILE *f=NULL;
FILE *g=NULL;
char m[100],message[10],er[100];
int jour,heure,num_capteur;
char valeur_debit[10];
f=fopen("debit.txt","r");
g=fopen("dash.txt","a+");
if (f!=NULL )
{
while (fscanf(f,"%d %d %d %s \n",&jour,&heure,&num_capteur,&valeur_debit)!=EOF)
{
printf("%d %d %d %s \n",jour,heure,num_capteur,valeur_debit);
if (atoi(valeur_debit)>30)
{
if (g!=NULL)
{
fprintf(g,"%d %d %d %s\n",jour,heure,num_capteur,valeur_debit);
}
}
}
fclose(f);
fclose(g);
}
g=fopen("dash.txt","r");
if (g!=NULL)
{
while (fscanf(g,"%d %d %d %s \n",&jour,&heure,&num_capteur,&valeur_debit)!=EOF)
{
strcpy(message,"l'etage ");
sprintf(er,"%d",num_capteur);
strcat(message,er);
sprintf(m,"%s\n",message);
break;
}
fclose(g);
}
output=lookup_widget(button,"label39_das");
gtk_label_set_text(GTK_LABEL(output),m);
}


void
on_radiobutton1_h_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
   if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
xo=1;
}
}


void
on_radiobutton2_f_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
xo=0;
}
}


void
on_button1_GH_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
  GtkWidget *dad1,*dad2,*dad3,*dad4;
  if (xo==1)
{
GtkWidget *treeview1_user;
   treeview1_user=lookup_widget(objet,"treeview1_user");
   if (chercher_homme("user.txt")==1)
   {
      dad1=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"utilisateur trouve avec succes selon sexe!");
switch (gtk_dialog_run(GTK_DIALOG(dad1)))
{
case GTK_RESPONSE_OK:
gtk_widget_destroy(dad1);
break; 
}
   rechercher_homme(treeview1_user);
   }
else
{
  dad2=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"pas d'utilisateurs selon ce sexe!");
switch (gtk_dialog_run(GTK_DIALOG(dad2)))
{
case GTK_RESPONSE_OK:
gtk_widget_destroy(dad2);
break; 
}
}
}
else
{
   GtkWidget *treeview1_user;
   treeview1_user=lookup_widget(objet,"treeview1_user"); 
   if (chercher_femme("user.txt")==1)
   {
      dad3=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"utilisateur trouve avec succes selon sexe!");
switch (gtk_dialog_run(GTK_DIALOG(dad3)))
{
case GTK_RESPONSE_OK:
gtk_widget_destroy(dad3);
break; 
}
   rechercher_femme(treeview1_user);
   }
else
{
  dad4=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"pas d'utilisateurs selon ce sexe!");
switch (gtk_dialog_run(GTK_DIALOG(dad4)))
{
case GTK_RESPONSE_OK:
gtk_widget_destroy(dad4);
break; 
}
}
}
}



void
on_button2_etud_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button3_af_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button4_ar_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button5_nut_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button6_tec_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button1_Seeee_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_search_close                        (GtkDialog       *dialog,
                                        gpointer         user_data)
{
  
}


void
on_button1_Ver_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button1_Mv_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button1_tit_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button1_Okv_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}
void
on_button1_Sz_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{}
void
on_button4_re_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{}
