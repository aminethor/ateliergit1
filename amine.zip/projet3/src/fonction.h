#include <gtk/gtk.h>
typedef struct {
              char nom[100];
              char prenom[100];
              char login[100];
              char password[100];
              int role;   
              char id[100];
              char date[100];
              char sexe[100];}utilisateur;
void ajouter_i(char nom_fichier[],utilisateur u);
void modifier_no(char nom_fichier[],utilisateur u);
void supprimer(char nom_fichier[],char Id[]);
int chercher(char nom_fichier[],char Id[]);
//void afficher(char nom_fichier[]);
void afficher_u(GtkWidget *liste);
void stat();
void suppr(utilisateur u);
void rechercher_k(GtkWidget *liste,char Id[]);
void rechercher_homme(GtkWidget *liste);
void rechercher_femme(GtkWidget *liste);
int chercher_homme(char ch[]);
int chercher_femme(char ch[]);

