#include <gtk/gtk.h>


void
on_button1_valider_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_dec_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton1_aff_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_aj_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button5_ok_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button6_recher_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button4_re_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button7_ajou_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button8_modif_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_button10_Delete_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_user_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);


void
on_button1_aff_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton1_xo_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_aq_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_kn_clicked                  (GtkButton       *button,
                                        gpointer         user_data);
void
on_button1_ax_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button1_Bn_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button2_Vc_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button1_Sz_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_AFf_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_h_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_f_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_GH_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data);



void
on_button2_etud_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_af_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_ar_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_nut_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_tec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_Seeee_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_search_close                        (GtkDialog       *dialog,
                                        gpointer         user_data);

void
on_button1_Ver_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_Mv_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_tit_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_Okv_clicked                 (GtkButton       *button,
                                        gpointer         user_data);
